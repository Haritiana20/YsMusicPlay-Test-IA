# Ys Music Play V5.0-dev

Ity dia **build de développement**, tsy APK final voamarina.

## Fanovana efa natao amin'ity fototra V5 ity
- Nohavaozina ho versionName `5.0-dev` sy versionCode `50`.
- Nohatsaraina ny fandanjalanjana ny pochette rectangulaire ao amin'ny Now Playing mba tsy hanery ny lohatenin-kira sy ny commandes amin'ny écran kely.
- Nampiana réglage Pitch misaraka amin'ny vitesse ao amin'ny lecteur audio, amin'ny alalan'ny Media3 PlaybackParameters.
- Notazonina ny EQ, Bass Boost, Shuffle, Previous, Next, Repeat ary ny moteur de séparation efa ao amin'ny V4.1 source.

## Zavatra mbola tsy azo lazaina ho vita
- Tsy mbola nampidirina ny fader Vocal/Instrumental temps réel mitovy amin'ny VirtualDJ. Ny séparation AI batch ankehitriny dia tsy midika hoe afaka mix-na mivantana ireo stems.
- Tsy mbola vita ny fanavaozana feno ny menu vidéo 3 points, suppression, informations détaillées ary thumbnails.
- Tsy mbola voamarina ny boost volume 300% amin'ny fitaovana tena izy; mety hiteraka clipping sy distorsion.
- Tsy azo antoka ny lecture vidéo YouTube en arrière-plan amin'ny WebView; hajaina ny fepetra YouTube ary tsy atao bypass.
- Mbola API 29+ sy arm64-v8a ihany ny build config satria tsy mbola voamarina fa manohana Android 7 sy armeabi-v7a ny dépendance native Demucs. Tsy nampidina an-jambany ny minSdk satria mety hahatonga build tsy mandeha na crash izany.
- Ny performance 1080p/4K dia miankina amin'ny codec sy hardware decoder an'ilay téléphone.

## Build
1. Apetraho ao amin'ny root repository ny `YsMusicPlay_V5_DEV.zip` (aza décompresser).
2. Apetraho ao amin'ny `.github/workflows/build.yml` ny workflow nomena.
3. Alefaso GitHub Actions.
4. Raha misy échec dia alefaso ny logs manontolo.

Tsy mbola nisy Android compilation na test appareil nahomby voamarina tamin'ity source ity. Aza raisina ho V5 final raha tsy tafavoaka ny build sy ny test amin'ny téléphone.
