# Ys Music Play V6.0-dev

Ity no fototra fampandrosoana V6, nalaina avy amin'ny source V5 FINAL voatahiry. Tsy V6 FINAL izy ity mandra-pahavitan'ny fanovana sy ny fanamarinana.

## Fototra notazonina
- Audio player sy Now Playing misy pochette rectangulaire.
- Equalizer, Bass Boost, Shuffle, Previous, Next ary Repeat OFF / ONE / ALL.
- Pitch audio 0.5x–5.0x sy reset 1.0x.
- Video player misy réglage vitesse sy Pitch misaraka ary reset.
- Sleep Timer / arrêt automatique nesorina.
- Séparation AI batch Demucs efa misy: mitahiry Vocal sy Instrumental WAV.
- Recherche YouTube intégrée amin'ny WebView (mila fanamarinana sy fanatsarana).
- Build config kendrena Android 7+ (minSdk 24), armeabi-v7a sy arm64-v8a; mila build CI mahomby vao azo lazaina fa voamarina.

## Asa V6 mbola tsy vita
1. Faders Vocal sy Instrumental tena mifehy ireo stems mandritra ny playback, miaraka amin'ny synchronisation sy controls.
2. Fitehirizana sy famerenana misafidy Vocal Only, Instrumental Only ary Original.
3. Fanatsarana Video: menu 3 points feno, rotation/lock, gesture brightness/volume, thumbnails sy metadata marina.
4. Fanamarinana YouTube search sy fitondran-tena mifanaraka amin'ny fepetra ofisialy; tsy atao bypass ny fameperana background playback.
5. Fanatsarana settings: thèmes sy fitahirizana preferences.
6. Fanamarinana ireo menus sy actions rehetra fa tsy UI fotsiny.
7. Build sy test amin'ny ABI roa ary fitaovana Android tena izy.

## Fanamarihana teknika
- Ny séparation AI dia mavesatra amin'ny CPU/RAM; tsy azo antoka ny faharetany amin'ny finday 4 GB RAM raha tsy refesina.
- Ny 1080p/4K dia miankina amin'ny codec sy hardware decoder.
- Ny volume boost avo dia mety hiteraka clipping; mila limiter sy fitsapana amim-pitandremana.
- Tsy mbola voamarina eto ny compilation Android.

## Build GitHub Actions
Ampidiro ao amin'ny repository ny `YsMusicPlay_V6_DEV.zip` sy ny workflow `build.yml`, dia alefaso ny workflow. Hamarino ny logs sy ny APK artifact.
