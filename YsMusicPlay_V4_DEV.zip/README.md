# Ys Music Play V4.0 — DEV

Source de développement Android Kotlin / Jetpack Compose basée sur l'archive V3.3 fournie.

## Changements dans cette archive
- Version Android mise à jour en 4.0 (`versionCode 40`).
- Conservation de l'interface Now Playing avec grande pochette rectangulaire : elle n'est pas remplacée par un petit disque.
- Conservation des commandes Shuffle, Précédent, Lecture/Pause, Suivant et Repeat OFF / ONE / ALL.
- La recherche YouTube déclenchée depuis Vocal/Instrumental s'affiche maintenant dans une WebView intégrée à l'application, au lieu de lancer une application externe.
- Conservation des préférences de thème sombre/clair et des couleurs déjà présentes dans la base V3.3.
- Workflow GitHub Actions configuré pour recevoir le ZIP source sans extraction manuelle sur le téléphone.

## Limites importantes — ne pas présenter comme terminé
- La séparation IA réelle Vocal / Instrumental hors ligne n'est PAS intégrée dans cette archive. Les choix Vocal/Instrumental actuels ouvrent des recherches YouTube intégrées; ils ne séparent pas le fichier audio local.
- La WebView affiche les résultats YouTube. La lecture reste soumise aux règles et restrictions de YouTube; cette intégration n'est pas un téléchargeur audio.
- Cette archive n'a pas été compilée ni testée sur un appareil Android dans l'environnement de préparation. La compilation GitHub Actions doit être vérifiée avant installation.

## Build GitHub Actions sans décompresser sur le téléphone
1. Créez un dépôt GitHub vide.
2. Téléversez `YsMusicPlay_V4_DEV.zip` à la racine du dépôt, sans le décompresser.
3. Téléversez le fichier `build.yml` dans `.github/workflows/build.yml` (créez les dossiers si nécessaire).
4. Ouvrez **Actions** puis **Build Ys Music Play V4** et lancez **Run workflow**.
5. Si le workflow réussit, ouvrez le run et téléchargez l'artifact `YsMusicPlay-V4-APK`.

Le succès du build confirme la compilation, pas le fonctionnement sur chaque appareil.
