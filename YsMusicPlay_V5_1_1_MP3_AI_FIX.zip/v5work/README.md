# Ys Music Play V5.1-dev — MP3 Interface & AI Separation

Cette version part du source V5 DEV et concentre les changements sur le lecteur MP3 et le traitement Vocal/Instrumental.

## Modifications
- Interface Now Playing réorganisée en disposition compacte : pochette rectangulaire, titre/artiste, barre de progression et commandes principales sur une seule ligne.
- Ordre des commandes conservé : Aléatoire, Précédent, Lecture/Pause, Suivant, Répétition.
- Contrôles Vitesse et Pitch passés en curseurs continus, avec Pitch de 0,5x à 5,0x et bouton Reset à 1,0x.
- Favoris, Tononkira, Séparation, EQ, Alvin, Boost et Filaharana regroupés en rangées compactes.
- Le modèle Demucs déjà chargé dans le processus n'est plus rechargé inutilement à chaque séparation.
- Le calcul SHA-256 du modèle est effectué par blocs pour éviter de charger tout le fichier modèle en mémoire.
- Le moteur de séparation utilise une configuration CPU à deux threads de calcul pour tenter d'accélérer le traitement, avec une consommation mémoire potentiellement supérieure à un seul thread.
- Version Android : versionName 5.1-dev, versionCode 51.

## Conservé depuis V5
- Bibliothèque audio, lecture Media3, favoris, file d'attente, répétition, EQ/Bass Boost et séparation Demucs hors ligne.
- Les fonctions vidéo et les autres écrans non concernés n'ont pas été volontairement remaniés.

## Limites et vérification
- La séparation reste un traitement IA par fichier, pas une séparation temps réel avec deux faders de mixage.
- Le gain réel de vitesse dépend du processeur, de la mémoire et du moteur natif. La configuration à deux threads doit être mesurée sur l'appareil cible ; si elle provoque une pression mémoire, revenir à un thread.
- Le modèle doit être téléchargé une première fois ; ensuite, la séparation peut fonctionner hors ligne.
- Configuration de cette base : minSdk 29 et ABI arm64-v8a uniquement. Aucune compatibilité Android 7 ou armeabi-v7a n'est revendiquée.
- Le workflow GitHub Actions doit compiler le projet. Aucun build Android ni test sur téléphone n'a été exécuté dans cet environnement.
