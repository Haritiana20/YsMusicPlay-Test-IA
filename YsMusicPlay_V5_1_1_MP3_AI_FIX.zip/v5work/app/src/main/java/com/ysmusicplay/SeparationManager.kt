package com.ysmusicplay

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import kotlin.math.min

object SeparationManager {
    private const val MODEL_URL = "https://huggingface.co/adefossez/HTDemucs-6s/resolve/3c5ee475be622df764938de97e4281a7b07ffa58/5c90dfd2.safetensors"
    private const val MODEL_SHA256 = "d2a1745f0744721f6b8ca5bf469b67c651ea5ed1b52998cab033b2158609d411"
    private const val MODEL_NAME = "5c90dfd2.safetensors"

    suspend fun separate(context: Context, source: Uri, progress: (String) -> Unit): Pair<Uri, Uri> = withContext(Dispatchers.IO) {
        val model = File(context.filesDir, MODEL_NAME)
        if (!model.exists() || sha256(model) != MODEL_SHA256) {
            progress("Misintona ny modely AI (55 MB)...")
            downloadModel(model, progress)
        }
        progress("Mamaky sy manova ny audio...")
        val raw = File(context.cacheDir, "ys_input_${System.currentTimeMillis()}.f32")
        val prepared = File(context.cacheDir, "ys_prepared_${System.currentTimeMillis()}.f32")
        val output = File(context.cacheDir, "ys_stems_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val format = decodeToFloat(context, source, raw)
            progress("Manomana ny modely AI...")
            NativeEngine.loadModel(model.absolutePath)
            NativeEngine.prepareInput(raw.absolutePath, format.first, format.second, prepared.absolutePath)
            progress("Manasaraka Vocal sy Instrumental. Mety haharitra...")
            NativeEngine.separate(prepared.absolutePath, output.absolutePath, threads = 2, computeThreads = 2, gpu = false) { fraction, stage ->
                progress("Séparation ${(fraction * 100).toInt()}% — $stage")
                true
            }
            val vocal = File(output, "vocals.wav")
            val instrumental = File(output, "instrumental.wav")
            val instrumentalParts = listOf("drums.wav", "bass.wav", "other.wav", "guitar.wav", "piano.wav").map { File(output, it) }.filter { it.exists() }
            if (!vocal.exists() || instrumentalParts.isEmpty()) error("Tsy feno ny vokatra navoakan'ny modèle AI.")
            mixWav(instrumentalParts, instrumental)
            progress("Mitahiry ny rakitra Vocal sy Instrumental...")
            val vocalUri = saveAudio(context, vocal, "${sourceName(context, source)}_Vocal.wav")
            val instrumentalUri = saveAudio(context, instrumental, "${sourceName(context, source)}_Instrumental.wav")
            progress("Vita: voatahiry ao amin'ny Music/YsMusicPlay.")
            vocalUri to instrumentalUri
        } finally {
            raw.delete(); prepared.delete(); output.deleteRecursively()
        }
    }

    private fun downloadModel(file: File, progress: (String) -> Unit) {
        val part = File(file.parentFile, file.name + ".part")
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply { connectTimeout = 20000; readTimeout = 60000; instanceFollowRedirects = true }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("Tsy afaka nisintona ny modely AI (HTTP ${connection.responseCode}).")
            connection.inputStream.use { input -> FileOutputStream(part).use { out ->
                val buffer = ByteArray(64 * 1024); var total = 0L; val expected = connection.contentLengthLong
                while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n); total += n
                    if (expected > 0) progress("Misintona modely AI ${(total * 100 / expected).toInt()}%...")
                }
            } }
        } finally { connection.disconnect() }
        if (sha256(part) != MODEL_SHA256) { part.delete(); error("Tsy mifanaraka ny SHA-256 an'ilay modely AI; avereno ny téléchargement.") }
        if (file.exists()) file.delete()
        if (!part.renameTo(file)) { part.copyTo(file, overwrite = true); part.delete() }
    }

    private fun decodeToFloat(context: Context, uri: Uri, out: File): Pair<Int, Int> {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        val track = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            ?: error("Tsy nahita piste audio tao amin'ilay fichier.")
        extractor.selectTrack(track)
        val inputFormat = extractor.getTrackFormat(track)
        val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(inputFormat, null, null, 0); decoder.start()
        var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var inputDone = false; var outputDone = false
        val info = MediaCodec.BufferInfo()
        FileOutputStream(out).use { stream ->
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inputIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) { decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                        else { decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0); extractor.advance() }
                    }
                }
                val outputIndex = decoder.dequeueOutputBuffer(info, 10000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = decoder.outputFormat
                        sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    outputIndex >= 0 -> {
                        val buffer = decoder.getOutputBuffer(outputIndex)!!.order(ByteOrder.LITTLE_ENDIAN)
                        if (info.size > 0) {
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            val encoding = if (Build.VERSION.SDK_INT >= 24 && decoder.outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) decoder.outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else android.media.AudioFormat.ENCODING_PCM_16BIT
                            val floats = ByteBuffer.allocate((info.size / if (encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) 4 else 2) * 4).order(ByteOrder.LITTLE_ENDIAN)
                            if (encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) while (buffer.remaining() >= 4) floats.putFloat(buffer.float)
                            else while (buffer.remaining() >= 2) floats.putFloat(buffer.short / 32768f)
                            stream.write(floats.array(), 0, floats.position())
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
        }
        decoder.stop(); decoder.release(); extractor.release()
        return sampleRate to channels
    }

    private data class WavInfo(val channels: Int, val rate: Int, val dataOffset: Long, val dataSize: Long)
    private fun wavInfo(file: File): WavInfo {
        java.io.RandomAccessFile(file, "r").use { raf ->
            raf.seek(12); var channels = 2; var rate = 44100
            while (raf.filePointer + 8 <= raf.length()) {
                val idBytes = ByteArray(4); raf.readFully(idBytes); val id = String(idBytes, Charsets.US_ASCII)
                val size = Integer.reverseBytes(raf.readInt()).toLong() and 0xffffffffL
                val dataStart = raf.filePointer
                if (id == "fmt ") { raf.skipBytes(2); channels = java.lang.Short.reverseBytes(raf.readShort()).toInt(); rate = Integer.reverseBytes(raf.readInt()) }
                if (id == "data") return WavInfo(channels, rate, dataStart, min(size, raf.length() - dataStart))
                raf.seek(dataStart + size + (size and 1L))
            }
        }
        error("WAV format tsy fantatra: ${file.name}")
    }
    private fun mixWav(parts: List<File>, output: File) {
        val infos = parts.map { wavInfo(it) }
        val first = infos.first(); val dataSize = infos.minOf { it.dataSize }
        if (infos.any { it.channels != first.channels || it.rate != first.rate }) error("Tsy mitovy ny format an'ireo stems.")
        val blockSamples = 16384
        java.io.RandomAccessFile(output, "rw").use { out ->
            out.setLength(0); out.writeBytes("RIFF"); writeLeInt(out, (36L + dataSize).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()); out.writeBytes("WAVEfmt "); writeLeInt(out, 16); writeLeShort(out, 1); writeLeShort(out, first.channels); writeLeInt(out, first.rate); writeLeInt(out, first.rate * first.channels * 2); writeLeShort(out, first.channels * 2); writeLeShort(out, 16); out.writeBytes("data"); writeLeInt(out, dataSize.toInt())
            val inputs = parts.mapIndexed { index, file -> java.io.RandomAccessFile(file, "r").apply { seek(infos[index].dataOffset) } }
            try {
                var remaining = dataSize / 2
                while (remaining > 0) {
                    val count = min(blockSamples.toLong(), remaining).toInt()
                    val sums = IntArray(count)
                    inputs.forEach { input ->
                        val bytes = ByteArray(count * 2); input.readFully(bytes)
                        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until count) sums[i] += bb.short.toInt()
                    }
                    val outBytes = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (value in sums) outBytes.putShort(value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort())
                    out.write(outBytes.array()); remaining -= count
                }
            } finally { inputs.forEach { it.close() } }
        }
    }
    private fun writeLeInt(out: java.io.DataOutput, v: Int) { out.writeByte(v); out.writeByte(v ushr 8); out.writeByte(v ushr 16); out.writeByte(v ushr 24) }
    private fun writeLeShort(out: java.io.DataOutput, v: Int) { out.writeByte(v); out.writeByte(v ushr 8) }
    private fun leInt(b: ByteArray, p: Int) = ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).int
    private fun leShort(b: ByteArray, p: Int) = ByteBuffer.wrap(b, p, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(64 * 1024).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
    private fun sourceName(context: Context, uri: Uri): String = (uri.lastPathSegment ?: "YsMusicPlay").substringAfterLast('/').substringBeforeLast('.').take(50)
    private fun saveAudio(context: Context, file: File, name: String): Uri {
        val values = ContentValues().apply { put(MediaStore.Audio.Media.DISPLAY_NAME, name); put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/YsMusicPlay") }
        val uri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: error("Tsy afaka namorona fichier vokatra.")
        try { context.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } } ?: error("Tsy afaka nitahiry ny fichier.") }
        catch (e: Exception) { context.contentResolver.delete(uri, null, null); throw e }
        return uri
    }
}
