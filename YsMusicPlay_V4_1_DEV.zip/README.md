# Ys Music Play V4.1 — DEV

## Nohavaozina
- Recherche Local / YouTube ao amin'ny pejy Audio iray ihany. Tsy manokatra écran YouTube misaraka intsony.
- Nampiana ny alalana Android `INTERNET` sy ny hafatra rehefa tsy tafiditra ny pejy YouTube.
- Ny séparation Vocal / Instrumental dia mampiasa Demucs Android C++ (`htdemucs_6s`) amin'ny appareil, fa tsy fikarohana YouTube.
- Misintona modely AI 55 MB indray mandeha, manamarina SHA-256, ary avy eo afaka miasa offline.
- Mamoaka `Vocal.wav` sy `Instrumental.wav` ao amin'ny `Music/YsMusicPlay`.
- Mode CPU, segment/thread iray ary arm64-v8a no ampiasaina ho fanombohana amin'ny appareil 4 GB RAM. Tsy antoka fa tsy hisy OOM amin'ny hira lava na amin'ny appareil rehetra.
- Notazonina ny grande pochette rectangulaire sy ny commandes player teo aloha.

## Fepetra ara-teknika
- Android 10 (API 29) na vaovao kokoa.
- Architecture arm64-v8a.
- Connexion Internet ilaina amin'ny téléchargement voalohany ny modèle (~55 MB). Rehefa voatahiry sy voamarina ilay modely dia tsy mila Internet intsony amin'ny séparation.
- Ny séparation dia mety haharitra ela ary mety hampafana ny téléphone. Atombohy amin'ny hira fohy hanaovana test.

## GitHub Actions
1. Mamoròna repository vaovao.
2. Apetraho ao amin'ny root ilay `YsMusicPlay_V4_1_DEV.zip` (tsy décompresser).
3. Apetraho ao amin'ny `.github/workflows/build.yml` ilay `build.yml` nomena.
4. Sokafy Actions, alefaso `Build Ys Music Play V4.1`.
5. Rehefa vita dia alao ny artifact `YsMusicPlay-V4_1-APK`.

Ny workflow dia maka ho azy ny source engine Demucs sy ny Eigen submodule, ary manamboatra ny native library amin'ny NDK.

## Fanamarinana
Ity archive ity dia mbola mila compilation amin'ny GitHub Actions sy fitsapana amin'ny téléphone. Tsy milaza izahay fa efa voamarina ny APK raha tsy nahomby ny workflow sy ny test appareil.
